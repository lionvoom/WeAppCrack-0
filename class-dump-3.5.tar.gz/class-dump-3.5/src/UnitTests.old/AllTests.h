// -*- mode: ObjC -*-

#import <SenTestingKit/SenTestingKit.h>

@interface AllTests : SenTestCase
{
}

+ (id)defaultTestSuite;

@end
